from src.models.user import db
from datetime import datetime, timedelta
from enum import Enum

class SubscriptionTier(Enum):
    FREE = "free"
    PREMIUM = "premium"

class UserSubscription(db.Model):
    __tablename__ = 'user_subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), unique=True, nullable=False)  # Bubble.io user ID
    tier = db.Column(db.Enum(SubscriptionTier), default=SubscriptionTier.FREE, nullable=False)
    
    # Subscription details
    subscription_start = db.Column(db.DateTime, nullable=True)
    subscription_end = db.Column(db.DateTime, nullable=True)
    is_trial = db.Column(db.Boolean, default=False)
    trial_end = db.Column(db.DateTime, nullable=True)
    
    # Usage tracking for free tier limits
    stories_created_this_month = db.Column(db.Integer, default=0)
    story_segments_this_month = db.Column(db.Integer, default=0)
    last_usage_reset = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Subscription management
    stripe_customer_id = db.Column(db.String(100), nullable=True)
    stripe_subscription_id = db.Column(db.String(100), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'tier': self.tier.value,
            'subscription_start': self.subscription_start.isoformat() if self.subscription_start else None,
            'subscription_end': self.subscription_end.isoformat() if self.subscription_end else None,
            'is_trial': self.is_trial,
            'trial_end': self.trial_end.isoformat() if self.trial_end else None,
            'stories_created_this_month': self.stories_created_this_month,
            'story_segments_this_month': self.story_segments_this_month,
            'is_active': self.is_subscription_active(),
            'can_create_stories': self.can_create_stories(),
            'can_use_premium_features': self.can_use_premium_features(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def is_subscription_active(self):
        """Check if subscription is currently active"""
        if self.tier == SubscriptionTier.FREE:
            return True
        
        now = datetime.utcnow()
        
        # Check trial period
        if self.is_trial and self.trial_end:
            return now <= self.trial_end
        
        # Check paid subscription
        if self.subscription_end:
            return now <= self.subscription_end
        
        return False
    
    def can_use_premium_features(self):
        """Check if user can access premium features"""
        if self.tier == SubscriptionTier.PREMIUM and self.is_subscription_active():
            return True
        return False
    
    def can_create_stories(self):
        """Check if user can create new stories based on tier limits"""
        if self.can_use_premium_features():
            return True
        
        # Free tier limits
        FREE_TIER_STORY_LIMIT = 5  # 5 stories per month
        
        # Reset monthly usage if needed
        self._reset_monthly_usage_if_needed()
        
        return self.stories_created_this_month < FREE_TIER_STORY_LIMIT
    
    def can_continue_story(self):
        """Check if user can continue stories based on tier limits"""
        if self.can_use_premium_features():
            return True
        
        # Free tier limits
        FREE_TIER_SEGMENT_LIMIT = 50  # 50 segments per month
        
        # Reset monthly usage if needed
        self._reset_monthly_usage_if_needed()
        
        return self.story_segments_this_month < FREE_TIER_SEGMENT_LIMIT
    
    def increment_story_count(self):
        """Increment story creation count"""
        self._reset_monthly_usage_if_needed()
        self.stories_created_this_month += 1
        self.updated_at = datetime.utcnow()
    
    def increment_segment_count(self):
        """Increment story segment count"""
        self._reset_monthly_usage_if_needed()
        self.story_segments_this_month += 1
        self.updated_at = datetime.utcnow()
    
    def _reset_monthly_usage_if_needed(self):
        """Reset monthly usage counters if a new month has started"""
        now = datetime.utcnow()
        if (now.year > self.last_usage_reset.year or 
            now.month > self.last_usage_reset.month):
            self.stories_created_this_month = 0
            self.story_segments_this_month = 0
            self.last_usage_reset = now
    
    def start_trial(self, trial_days=7):
        """Start a free trial"""
        if self.tier != SubscriptionTier.FREE:
            return False
        
        self.tier = SubscriptionTier.PREMIUM
        self.is_trial = True
        self.subscription_start = datetime.utcnow()
        self.trial_end = datetime.utcnow() + timedelta(days=trial_days)
        self.updated_at = datetime.utcnow()
        return True
    
    def upgrade_to_premium(self, subscription_months=1):
        """Upgrade to premium subscription"""
        self.tier = SubscriptionTier.PREMIUM
        self.is_trial = False
        self.subscription_start = datetime.utcnow()
        self.subscription_end = datetime.utcnow() + timedelta(days=30 * subscription_months)
        self.trial_end = None
        self.updated_at = datetime.utcnow()
    
    def downgrade_to_free(self):
        """Downgrade to free tier"""
        self.tier = SubscriptionTier.FREE
        self.is_trial = False
        self.subscription_start = None
        self.subscription_end = None
        self.trial_end = None
        self.stripe_customer_id = None
        self.stripe_subscription_id = None
        self.updated_at = datetime.utcnow()
    
    @staticmethod
    def get_or_create_subscription(user_id):
        """Get existing subscription or create new free tier subscription"""
        subscription = UserSubscription.query.filter_by(user_id=user_id).first()
        if not subscription:
            subscription = UserSubscription(user_id=user_id)
            db.session.add(subscription)
            db.session.commit()
        return subscription


class FeatureUsage(db.Model):
    __tablename__ = 'feature_usage'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    feature_name = db.Column(db.String(50), nullable=False)  # 'story_creation', 'image_generation', etc.
    usage_count = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'feature_name': self.feature_name,
            'usage_count': self.usage_count,
            'created_at': self.created_at.isoformat()
        }
    
    @staticmethod
    def log_feature_usage(user_id, feature_name):
        """Log usage of a specific feature"""
        usage = FeatureUsage(
            user_id=user_id,
            feature_name=feature_name
        )
        db.session.add(usage)
        db.session.commit()
        return usage

